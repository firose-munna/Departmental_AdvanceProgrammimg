package bubt.quizzes;


public class BUBTQUIZZES {

    
    public static void main(String[] args) {
        
    }
    
}
